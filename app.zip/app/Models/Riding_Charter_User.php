<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Riding_Charter_User extends Model
{
    use HasFactory;
    protected $table = 'riding_charter_users';
}
