<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\New_User;
use DB;
use Validator;

class NotificationController extends Controller
{
    public function index()
    {
        $data = New_User::all();
        // return $data;
        return view('admin.notification.index',compact('data'));
    }

    public function sendNotification(Request $request)
    {
        $valid = Validator::make($request->all(),[
            'users'   => 'required|array',
            'message' => 'required'
        ],[
            'users.required' => 'Choose users from dropdown',
            'users.array' => 'Incorrect Format',
            'message.required' => 'Message cannot be empty'
        ]);

        if($valid->fails()) {
            return back()->withErrors($valid);
        }

        return $request;
    }
}
