<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Riding_Charter_Users;
use App\Models\Product;
use Validator;
use Hash;
use DB;
use Mail;

class ShopController extends Controller {

    public function allProducts()
    {
        $data = Product::paginate(20);
        return response()->json($data);
    }

}