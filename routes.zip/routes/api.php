<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\ProfileController;
use App\Mail\sendOtp;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


Route::middleware('auth:sanctum')->get('/profile/view', function (Request $request) {
    
     return $request->user();
});

Route::group(['middleware' => 'auth:sanctum'],function () {
    Route::apiResource('profile', ProfileController::class);
});
//
//Route::put('update/{{$request->user()}}',[AuthController::class, 'update'])->name('profile.update');
//
//Route::get('view/{{$request->user()}}',[AuthController::class, 'view'])->name('profile.view');



Route::post('login',[AuthController::class, 'login'])->name('login');

Route::post('signup',[AuthController::class, 'signup'])->name('signup');

Route::post('sendOtp',[AuthController::class, 'sendOtp'])->name('sendOtp');

Route::post('verify',[AuthController::class, 'verify'])->name('verify');

Route::post('change_password',[AuthController::class, 'change_password'])->name('change_password');

//Route::get('/sendOtp', function() {
//
//    Mail::to('hetsheth40@gmail.com');
//});
