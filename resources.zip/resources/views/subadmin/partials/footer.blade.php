<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © Nazox.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesdesign
                </div>
            </div>
        </div>
    </div>
</footer>

</div>
<!-- end main content-->

</div>
<!-- END layout-wrapper -->

<!-- JAVASCRIPT -->
<script src="{{ url('public/assets/dashboard-nazox/assets/libs/jquery/jquery.min.js') }}"></script>
<script src="{{ url('public/assets/dashboard-nazox/assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ url('public/assets/dashboard-nazox/assets/libs/metismenu/metisMenu.min.js') }}"></script>
<script src="{{ url('public/assets/dashboard-nazox/assets/libs/simplebar/simplebar.min.js') }}"></script>
<script src="{{ url('public/assets/dashboard-nazox/assets/libs/node-waves/waves.min.js') }}"></script>



<!-- jquery.vectormap map -->
<script src="{{ url('public/assets/dashboard-nazox/assets/libs/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js') }}"></script>
<script src="{{ url('public/assets/dashboard-nazox/assets/libs/admin-resources/jquery.vectormap/maps/jquery-jvectormap-us-merc-en.js') }}"></script>

<!-- Required datatable js -->
<script src="{{ url('public/assets/dashboard-nazox/assets/libs/datatables.net/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ url('public/assets/dashboard-nazox/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js') }}"></script>

<!-- Responsive examples -->
<script src="{{ url('public/assets/dashboard-nazox/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ url('public/assets/dashboard-nazox/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js') }}"></script>

{{-- <script src="{{ url('assets/dashboard-nazox/assets/js/pages/dashboard.init.js') }}"></script> --}}

<!-- App js -->
<script src="{{ url('public/assets/dashboard-nazox/assets/js/app.js') }}"></script>
<script src="{{ url('public/assets/dashboard-nazox/assets/libs/dropzone/min/dropzone.min.js') }}"></script>
<script src="{{ url('public/assets/dropzone-scripts.js') }}"></script>

<!-- Magnific Popup-->
<script src="{{ url('public/assets/dashboard-nazox/assets/libs/magnific-popup/jquery.magnific-popup.min.js') }}"></script>

<!-- lightbox init js-->
<script src="{{ url('public/assets/dashboard-nazox/assets/js/pages/lightbox.init.js') }}"></script>